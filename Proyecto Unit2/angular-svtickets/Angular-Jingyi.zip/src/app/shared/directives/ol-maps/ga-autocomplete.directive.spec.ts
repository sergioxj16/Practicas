import { GaAutocompleteDirective } from './ga-autocomplete.directive';

describe('GaAutocompleteDirective', () => {
  it('should create an instance', () => {
    const directive = new GaAutocompleteDirective();
    expect(directive).toBeTruthy();
  });
});
