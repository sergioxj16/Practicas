import { OlMarkerDirective } from './ol-marker.directive';

describe('OlMarkerDirective', () => {
  it('should create an instance', () => {
    const directive = new OlMarkerDirective();
    expect(directive).toBeTruthy();
  });
});
