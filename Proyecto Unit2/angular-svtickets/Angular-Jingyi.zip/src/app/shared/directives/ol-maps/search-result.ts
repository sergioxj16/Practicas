export interface SearchResult {
    coordinates: [number, number];
    address: string;
  }