import { GoogleLoginDirective } from "./google-login.directive";


describe('GoogleLoginDirective', () => {
  it('should create an instance', () => {
    const directive = new GoogleLoginDirective();
    expect(directive).toBeTruthy();
  });
});
