import { MinDateDirective } from './min-date.directive';

describe('MinDateDirective', () => {
  it('should create an instance', () => {
    const directive = new MinDateDirective();
    expect(directive).toBeTruthy();
  });
});
