import { OlMapDirective } from './ol-map.directive';

describe('OlMapDirective', () => {
  it('should create an instance', () => {
    const directive = new OlMapDirective();
    expect(directive).toBeTruthy();
  });
});
