import { ValidationClassesDirective } from './validation-classes.directive';

describe('ValidationClassesDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidationClassesDirective();
    expect(directive).toBeTruthy();
  });
});
