"use strict";

function setValidInput(input, valid) {
    input.classList.remove("is-valid", "is-invalid");
    if (valid) {
        input.classList.add("is-valid");
    } else {
        input.classList.add("is-invalid");
    }
}
// expr.test(input.value)
function validatePrice() {
    const valid = newEventForm.price.value && newEventForm.price.value > 0;
    setValidInput(newEventForm.price, valid);
    return valid;
}

function validateTitle() {
    const valid = /[a-z][a-z ]*/.test(newEventForm.title.value);
    setValidInput(newEventForm.title, valid);
    return valid;
}

function validateDescription() {
    const valid = /.*\S.*/.test(newEventForm.description.value);
    setValidInput(newEventForm.description, valid);
    return valid;
}

function validateDate() {
    const valid = !!newEventForm.date.value;
    setValidInput(newEventForm.date, valid);
    return valid;
}

function validateImage() {
    const valid = newEventForm.image.files.length > 0 && newEventForm.image.files[0].type.startsWith('image');
    setValidInput(newEventForm.image, valid);
    return valid;
}

function validateForm(event) {
    event.preventDefault();
    const title = newEventForm.title.value;
    const image = imgPreview.src;
    const date = newEventForm.date.value;
    const desc = newEventForm.description.value;
    const price = newEventForm.price.value;

    const validations = [validateTitle(), validateDate(), validateDescription(), validatePrice(), validateImage()];

    if (validations.every(v => v === true)) { // Check all validations
        addEvent(title, image, date, desc, price);
        newEventForm.reset();
        imgPreview.classList.add("d-none");
        document.querySelectorAll(".form-control").forEach(
            input => input.classList.remove("is-valid", "is-invalid")
        );
    }
}

function loadImage(event) {
    const file = event.target.files[0];
    const reader = new FileReader();

    if (file) reader.readAsDataURL(file);

    reader.addEventListener('load', e => {
        imgPreview.classList.remove("d-none");
        imgPreview.src = reader.result;
    });
}

function addEvent(name, image, date, desc, price) {
    const container = document.getElementById("eventsContainer");

    const col = document.createElement("div");
    col.classList.add("col");
    container.append(col);

    const card = document.createElement("div");
    card.classList.add("card", "shadow");
    col.append(card);

    const img = document.createElement("img");
    img.classList.add("card-img-top");
    img.src = image;
    card.append(img);

    const cardBody = document.createElement("div");
    cardBody.classList.add("card-body");
    card.append(cardBody);

    const cardTitle = document.createElement("h4");
    cardTitle.classList.add("card-title");
    cardTitle.textContent = name;
    cardBody.append(cardTitle);

    const cardText = document.createElement("p");
    cardText.classList.add("card-text");
    cardText.innerText = desc;
    cardBody.append(cardText);

    const deleteBtn = document.createElement("button");
    deleteBtn.classList.add("btn", "btn-danger", "delete");
    const deleteIcon = document.createElement("i");
    deleteIcon.classList.add("bi", "bi-trash");
    deleteBtn.append(deleteIcon);
    cardBody.append(deleteBtn);

    deleteBtn.addEventListener("click", e => col.remove());

    const cardFooter = document.createElement("div");
    cardFooter.classList.add("card-footer", "text-muted", "row", "m-0");
    card.append(cardFooter);

    const dateObj = new Date(date);
    const dateFormatter = Intl.DateTimeFormat('en', {
        day: "2-digit", month: "2-digit", year: "numeric"
    });

    const dateText = document.createElement("div");
    dateText.classList.add("col");
    dateText.textContent = dateFormatter.format(dateObj);
    cardFooter.append(dateText);

    const priceFormatter = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'EUR' });
    const priceText = document.createElement("div");
    priceText.classList.add("col", "text-end");
    priceText.textContent = priceFormatter.format(+price);
    cardFooter.append(priceText);

}

const newEventForm = document.getElementById("newEvent");;
const imgPreview = document.getElementById("imgPreview");

newEventForm.image.addEventListener('change', loadImage);

newEventForm.addEventListener('submit', validateForm);
