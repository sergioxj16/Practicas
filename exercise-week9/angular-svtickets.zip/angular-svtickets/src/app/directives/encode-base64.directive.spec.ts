import { EncodeBase64Directive } from './encode-base64.directive';

describe('EncodeBase64Directive', () => {
  it('should create an instance', () => {
    const directive = new EncodeBase64Directive();
    expect(directive).toBeTruthy();
  });
});
